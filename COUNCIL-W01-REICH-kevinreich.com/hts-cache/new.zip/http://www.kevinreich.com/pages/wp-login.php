<!DOCTYPE html>
	<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Kevin Reich for City Council &rsaquo; Log In</title>
	<link rel='stylesheet' id='wp-admin-css'  href='http://www.kevinreich.com/pages/wp-admin/css/wp-admin.min.css?ver=3.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='http://www.kevinreich.com/pages/wp-includes/css/buttons.min.css?ver=3.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='colors-fresh-css'  href='http://www.kevinreich.com/pages/wp-admin/css/colors-fresh.min.css?ver=3.5.1' type='text/css' media='all' />
<script type='text/javascript' src='http://www.kevinreich.com/pages/wp-includes/js/jquery/jquery.js?ver=1.8.3'></script>
<script type='text/javascript' src='http://www.kevinreich.com/pages/wp-content/plugins/mailchimp/js/scrollTo.js?ver=1.2.13'></script>
<script type='text/javascript' src='http://www.kevinreich.com/pages/wp-includes/js/jquery/jquery.form.min.js?ver=2.73'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mailchimpSF = {"ajax_url":"http:\/\/www.kevinreich.com\/pages\/"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.kevinreich.com/pages/wp-content/plugins/mailchimp/js/mailchimp.js?ver=1.2.13'></script>
<script type='text/javascript' src='http://www.kevinreich.com/pages/wp-includes/js/jquery/ui/jquery.ui.core.min.js?ver=1.9.2'></script>
<script type='text/javascript' src='http://www.kevinreich.com/pages/wp-content/plugins/mailchimp//js/datepicker.js?ver=3.5.1'></script>
<meta name='robots' content='noindex,nofollow' />
	</head>
	<body class="login login-action-login wp-core-ui">
	<div id="login">
		<h1><a href="http://wordpress.org/" title="Powered by WordPress">Kevin Reich for City Council</a></h1>
	
<form name="loginform" id="loginform" action="http://www.kevinreich.com/pages/wp-login.php" method="post">
	<p>
		<label for="user_login">Username<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
	<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="http://www.kevinreich.com/pages/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
<a href="http://www.kevinreich.com/pages/wp-login.php?action=lostpassword" title="Password Lost and Found">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://www.kevinreich.com/pages/" title="Are you lost?">&larr; Back to Kevin Reich for City Council</a></p>
	
	</div>

	
	<link rel='stylesheet' id='flick-css'  href='http://www.kevinreich.com/pages/wp-content/plugins/mailchimp//css/flick/flick.css?ver=3.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='mailchimpSF_main_css-css'  href='http://www.kevinreich.com/pages/?mcsf_action=main_css&#038;ver=3.5.1' type='text/css' media='all' />
<!--[if IE]>
<link rel='stylesheet' id='mailchimpSF_ie_css-css'  href='http://www.kevinreich.com/pages/wp-content/plugins/mailchimp/css/ie.css?ver=3.5.1' type='text/css' media='all' />
<![endif]-->
	<div class="clear"></div>
	</body>
	</html>
	