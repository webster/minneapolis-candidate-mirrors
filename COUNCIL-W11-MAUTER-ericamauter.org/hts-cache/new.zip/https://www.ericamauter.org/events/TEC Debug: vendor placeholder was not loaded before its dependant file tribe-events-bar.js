<!DOCTYPE html>
<!--[if IE 6]><html
id="ie6" lang="en-US" xmlns:og="http://ogp.me/ns#" xmlns:fb="http://ogp.me/ns/fb#">
<![endif]-->
<!--[if IE 7]><html
id="ie7" lang="en-US" xmlns:og="http://ogp.me/ns#" xmlns:fb="http://ogp.me/ns/fb#">
<![endif]-->
<!--[if IE 8]><html
id="ie8" lang="en-US" xmlns:og="http://ogp.me/ns#" xmlns:fb="http://ogp.me/ns/fb#">
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!--><html
lang="en-US" xmlns:og="http://ogp.me/ns#" xmlns:fb="http://ogp.me/ns/fb#">
<!--<![endif]--><head><link
rel="stylesheet" type="text/css" href="https://www.ericamauter.org/wp-content/cache/minify/53431.css" media="all" /><meta
charset="UTF-8" /><link
rel="pingback" href="https://www.ericamauter.org/xmlrpc.php" /><!--[if lt IE 9]> <script src="https://www.ericamauter.org/wp-content/themes/Divi/js/html5.js" type="text/javascript"></script> <![endif]--> <script type="text/javascript">document.documentElement.className='js';</script> <title>404 Not Found | Erica Mauter</title><link
rel='dns-prefetch' href='//s0.wp.com' /><link
rel='dns-prefetch' href='//fonts.googleapis.com' /><link
rel='dns-prefetch' href='//s.w.org' /><link
rel="alternate" type="application/rss+xml" title="Erica Mauter &raquo; Feed" href="https://www.ericamauter.org/feed/" /><link
rel="alternate" type="application/rss+xml" title="Erica Mauter &raquo; Comments Feed" href="https://www.ericamauter.org/comments/feed/" /><link
rel="alternate" type="text/calendar" title="Erica Mauter &raquo; iCal Feed" href="https://www.ericamauter.org/events/?ical=1" /> <script type="text/javascript">/*<![CDATA[*/window._wpemojiSettings={"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.ericamauter.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=ff39c212faa91ab2fbd91cc5cfc2fec7"}};!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);/*]]>*/</script> <meta
content="ERICA MAUTER v.1.0" name="generator"/><style type="text/css">img.wp-smiley,img.emoji{display:inline !important;border:none !important;box-shadow:none !important;height:1em !important;width:1em !important;margin:0
.07em !important;vertical-align:-0.1em !important;background:none !important;padding:0
!important}</style><link
rel='stylesheet' id='et-gf-open-sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' type='text/css' media='all' /><link
rel='stylesheet' id='divi-fonts-css'  href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&#038;subset=latin,latin-ext' type='text/css' media='all' /><link
rel='stylesheet' id='et-gf-arvo-css'  href='https://fonts.googleapis.com/css?family=Arvo:400,400italic,700,700italic&#038;subset=latin' type='text/css' media='all' /><link
rel='stylesheet' id='et-gf-montserrat-css'  href='https://fonts.googleapis.com/css?family=Montserrat:400,700&#038;subset=latin' type='text/css' media='all' /><link
rel='stylesheet' id='et-gf-nunito-css'  href='https://fonts.googleapis.com/css?family=Nunito:400,300,700&#038;subset=latin' type='text/css' media='all' /><style id='jetpack_facebook_likebox-inline-css' type='text/css'>.widget_facebook_likebox{overflow:hidden}</style> <script type='text/javascript'>var tribe_events_linked_posts={"post_types":{"tribe_venue":"venue","tribe_organizer":"organizer"}};</script> <script async type="text/javascript" src="https://www.ericamauter.org/wp-content/cache/minify/df983.js"></script> <link
rel='https://api.w.org/' href='https://www.ericamauter.org/wp-json/' /><link
rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.ericamauter.org/xmlrpc.php?rsd" /><link
rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.ericamauter.org/wp-includes/wlwmanifest.xml" /> <script type="text/javascript">document.getElementsByTagName("html")[0].className+=" js";</script> <style type="text/css" id="et-social-custom-css">.et_monarch .et_social_sidebar_networks li, .et_monarch .et_social_mobile
li{background:#af1f32}.et_monarch .et_social_sidebar_networks .et_social_icons_container li:hover, .et_monarch .et_social_mobile .et_social_icons_container li:hover{background:#af1f32 !important}.et_social_sidebar_border
li{border-color:#af1f32 !important}.et_monarch .widget_monarchwidget .et_social_networks ul li, .et_monarch .widget_monarchwidget.et_social_circle li
i{background:#80b6c6 !important}.et_monarch .widget_monarchwidget.et_social_rounded .et_social_icons_container li:hover, .et_monarch .widget_monarchwidget.et_social_rectangle .et_social_icons_container li:hover, .et_monarch .widget_monarchwidget.et_social_circle .et_social_icons_container li:hover
i.et_social_icon{background:#80b6c6 !important}.et_monarch .widget_monarchwidget .et_social_icon, .et_monarch .widget_monarchwidget.et_social_networks .et_social_network_label, .et_monarch .widget_monarchwidget
.et_social_sidebar_count{color:#fff}.et_monarch .widget_monarchwidget .et_social_icons_container li:hover .et_social_icon, .et_monarch .widget_monarchwidget.et_social_networks .et_social_icons_container li:hover .et_social_network_label, .et_monarch .widget_monarchwidget .et_social_icons_container li:hover
.et_social_sidebar_count{color:#af1f32 !important}</style><script type="text/javascript">/*<![CDATA[*/(function(url){if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){return;}
var addEvent=function(evt,handler){if(window.addEventListener){document.addEventListener(evt,handler,false);}else if(window.attachEvent){document.attachEvent('on'+evt,handler);}};var removeEvent=function(evt,handler){if(window.removeEventListener){document.removeEventListener(evt,handler,false);}else if(window.detachEvent){document.detachEvent('on'+evt,handler);}};var evts='contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');var logHuman=function(){var wfscr=document.createElement('script');wfscr.type='text/javascript';wfscr.async=true;wfscr.src=url+'&r='+Math.random();(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);for(var i=0;i<evts.length;i++){removeEvent(evts[i],logHuman);}};for(var i=0;i<evts.length;i++){addEvent(evts[i],logHuman);}})('//www.ericamauter.org/?wordfence_logHuman=1&hid=814E9568BCBE83C8ADCED4D325A9751B');/*]]>*/</script> <link
rel='dns-prefetch' href='//v0.wordpress.com'><link
rel='dns-prefetch' href='//i0.wp.com'><link
rel='dns-prefetch' href='//i1.wp.com'><link
rel='dns-prefetch' href='//i2.wp.com'><style type='text/css'>img#wpstats{display:none}</style><meta
name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" /><style id="theme-customizer-css">@media only screen and ( min-width: 767px ){body, .et_pb_column_1_2 .et_quote_content blockquote cite, .et_pb_column_1_2 .et_link_content a.et_link_main_url, .et_pb_column_1_3 .et_quote_content blockquote cite, .et_pb_column_3_8 .et_quote_content blockquote cite, .et_pb_column_1_4 .et_quote_content blockquote cite, .et_pb_blog_grid .et_quote_content blockquote cite, .et_pb_column_1_3 .et_link_content a.et_link_main_url, .et_pb_column_3_8 .et_link_content a.et_link_main_url, .et_pb_column_1_4 .et_link_content a.et_link_main_url, .et_pb_blog_grid .et_link_content a.et_link_main_url, body .et_pb_bg_layout_light .et_pb_post p,  body .et_pb_bg_layout_dark .et_pb_post
p{font-size:16px}.et_pb_slide_content,.et_pb_best_value{font-size:18px}}.woocommerce #respond input#submit, .woocommerce-page #respond input#submit, .woocommerce #content input.button, .woocommerce-page #content input.button,.woocommerce-message,.woocommerce-error,.woocommerce-info{background:#af1f32 !important}#et_search_icon:hover, .mobile_menu_bar:before, .mobile_menu_bar:after, .et_toggle_slide_menu:after, .et-social-icon a:hover, .et_pb_sum, .et_pb_pricing li a, .et_pb_pricing_table_button, .et_overlay:before, .entry-summary p.price ins, .woocommerce div.product span.price, .woocommerce-page div.product span.price, .woocommerce #content div.product span.price, .woocommerce-page #content div.product span.price, .woocommerce div.product p.price, .woocommerce-page div.product p.price, .woocommerce #content div.product p.price, .woocommerce-page #content div.product p.price, .et_pb_member_social_links a:hover, .woocommerce .star-rating span:before, .woocommerce-page .star-rating span:before, .et_pb_widget li a:hover, .et_pb_filterable_portfolio .et_pb_portfolio_filters li a.active, .et_pb_filterable_portfolio .et_pb_portofolio_pagination ul li a.active, .et_pb_gallery .et_pb_gallery_pagination ul li a.active, .wp-pagenavi span.current, .wp-pagenavi a:hover, .nav-single a, .posted_in
a{color:#af1f32}.et_pb_contact_submit, .et_password_protected_form .et_submit_button, .et_pb_bg_layout_light .et_pb_newsletter_button, .comment-reply-link, .form-submit .et_pb_button, .et_pb_bg_layout_light .et_pb_promo_button, .et_pb_bg_layout_light .et_pb_more_button, .woocommerce a.button.alt, .woocommerce-page a.button.alt, .woocommerce button.button.alt, .woocommerce-page button.button.alt, .woocommerce input.button.alt, .woocommerce-page input.button.alt, .woocommerce #respond input#submit.alt, .woocommerce-page #respond input#submit.alt, .woocommerce #content input.button.alt, .woocommerce-page #content input.button.alt, .woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page
input.button{color:#af1f32}.footer-widget
h4{color:#af1f32}.et-search-form, .nav li ul, .et_mobile_menu, .footer-widget li:before, .et_pb_pricing li:before,blockquote{border-color:#af1f32}.et_pb_counter_amount, .et_pb_featured_table .et_pb_pricing_heading,.et_quote_content,.et_link_content,.et_audio_content,.et_pb_post_slider.et_pb_bg_layout_dark,.et_slide_in_menu_container{background-color:#af1f32}a{color:#af1f32}#main-header, #main-header .nav li ul, .et-search-form, #main-header
.et_mobile_menu{background-color:#80b6c6}.nav li
ul{border-color:#fff}#top-header, #et-secondary-nav li
ul{background-color:#80b6c6}#et-secondary-nav li
ul{background-color:#fff}#et-secondary-nav li ul
a{color:#80b6c6}.et_header_style_centered .mobile_nav .select_page, .et_header_style_split .mobile_nav .select_page, .et_nav_text_color_light #top-menu > li > a, .et_nav_text_color_dark #top-menu > li > a, #top-menu a, .et_mobile_menu li a, .et_nav_text_color_light .et_mobile_menu li a, .et_nav_text_color_dark .et_mobile_menu li a, #et_search_icon:before, .et_search_form_container input, span.et_close_search_field:after, #et-top-navigation .et-cart-info{color:#fff}.et_search_form_container input::-moz-placeholder{color:#fff}.et_search_form_container input::-webkit-input-placeholder{color:#fff}.et_search_form_container input:-ms-input-placeholder{color:#fff}#main-header .nav li ul
a{color:#af1f32}#top-menu li
a{font-size:18px}body.et_vertical_nav .container.et_search_form_container .et-search-form
input{font-size:18px !important}#top-menu li.current-menu-ancestor > a, #top-menu li.current-menu-item > a,
.et_color_scheme_red #top-menu li.current-menu-ancestor > a, .et_color_scheme_red #top-menu li.current-menu-item > a,
.et_color_scheme_pink #top-menu li.current-menu-ancestor > a, .et_color_scheme_pink #top-menu li.current-menu-item > a,
.et_color_scheme_orange #top-menu li.current-menu-ancestor > a, .et_color_scheme_orange #top-menu li.current-menu-item > a,
.et_color_scheme_green #top-menu li.current-menu-ancestor > a, .et_color_scheme_green #top-menu li.current-menu-item>a{color:#fff}#main-footer .footer-widget
h4{color:#af1f32}.footer-widget li:before{border-color:#af1f32}.footer-widget, .footer-widget li, .footer-widget li a,#footer-info{font-size:14px}#footer-bottom{background-color:#80b6c6}#footer-info, #footer-info
a{color:#fff}#footer-info{font-size:12px }#footer-bottom .et-social-icon
a{color:#fff}body .et_pb_button,
.woocommerce a.button.alt, .woocommerce-page a.button.alt, .woocommerce button.button.alt, .woocommerce-page button.button.alt, .woocommerce input.button.alt, .woocommerce-page input.button.alt, .woocommerce #respond input#submit.alt, .woocommerce-page #respond input#submit.alt, .woocommerce #content input.button.alt, .woocommerce-page #content input.button.alt,
.woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce #respond input#submit, .woocommerce-page #respond input#submit, .woocommerce #content input.button, .woocommerce-page #content input.button, .woocommerce-message a.button.wc-forward{background:#80b6c6;border-color:#80b6c6}body.et_pb_button_helper_class .et_pb_button,
.woocommerce.et_pb_button_helper_class a.button.alt, .woocommerce-page.et_pb_button_helper_class a.button.alt, .woocommerce.et_pb_button_helper_class button.button.alt, .woocommerce-page.et_pb_button_helper_class button.button.alt, .woocommerce.et_pb_button_helper_class input.button.alt, .woocommerce-page.et_pb_button_helper_class input.button.alt, .woocommerce.et_pb_button_helper_class #respond input#submit.alt, .woocommerce-page.et_pb_button_helper_class #respond input#submit.alt, .woocommerce.et_pb_button_helper_class #content input.button.alt, .woocommerce-page.et_pb_button_helper_class #content input.button.alt,
.woocommerce.et_pb_button_helper_class a.button, .woocommerce-page.et_pb_button_helper_class a.button, .woocommerce.et_pb_button_helper_class button.button, .woocommerce-page.et_pb_button_helper_class button.button, .woocommerce.et_pb_button_helper_class input.button, .woocommerce-page.et_pb_button_helper_class input.button, .woocommerce.et_pb_button_helper_class #respond input#submit, .woocommerce-page.et_pb_button_helper_class #respond input#submit, .woocommerce.et_pb_button_helper_class #content input.button, .woocommerce-page.et_pb_button_helper_class #content
input.button{}body .et_pb_button:hover,
.woocommerce a.button.alt:hover, .woocommerce-page a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce-page button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce-page input.button.alt:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce-page #respond input#submit.alt:hover, .woocommerce #content input.button.alt:hover, .woocommerce-page #content input.button.alt:hover,
.woocommerce a.button:hover, .woocommerce-page a.button:hover, .woocommerce button.button:hover, .woocommerce-page button.button:hover, .woocommerce input.button:hover, .woocommerce-page input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce-page #respond input#submit:hover, .woocommerce #content input.button:hover, .woocommerce-page #content input.button:hover{background:#80b6c6 !important;border-color:#af1f32 !important}@media only screen and ( min-width: 981px ){.footer-widget
h4{font-size:16px}.et_header_style_left #et-top-navigation, .et_header_style_split #et-top-navigation{padding:75px
0 0 0}.et_header_style_left #et-top-navigation nav > ul > li > a, .et_header_style_split #et-top-navigation nav>ul>li>a{padding-bottom:75px}.et_header_style_split .centered-inline-logo-wrap{width:150px;margin:-150px 0}.et_header_style_split .centered-inline-logo-wrap
#logo{max-height:150px}.et_pb_svg_logo.et_header_style_split .centered-inline-logo-wrap
#logo{height:150px}.et_header_style_centered #top-menu>li>a{padding-bottom:27px}.et_header_style_slide #et-top-navigation, .et_header_style_fullscreen #et-top-navigation{padding:66px
0 66px 0 !important}.et_header_style_centered #main-header
.logo_container{height:150px}.et_header_style_centered
#logo{max-height:100%}.et_pb_svg_logo.et_header_style_centered
#logo{height:100%}.et_header_style_centered.et_hide_primary_logo #main-header:not(.et-fixed-header) .logo_container, .et_header_style_centered.et_hide_fixed_logo #main-header.et-fixed-header
.logo_container{height:27px}.et-fixed-header#top-header, .et-fixed-header#top-header #et-secondary-nav li
ul{background-color:#fff}.et-fixed-header#main-header, .et-fixed-header#main-header .nav li ul, .et-fixed-header .et-search-form{background-color:#fff}.et-fixed-header #top-menu li
a{font-size:16px}.et-fixed-header #top-menu a, .et-fixed-header #et_search_icon:before, .et-fixed-header #et_top_search .et-search-form input, .et-fixed-header .et_search_form_container input, .et-fixed-header .et_close_search_field:after, .et-fixed-header #et-top-navigation .et-cart-info{color:#af1f32 !important}.et-fixed-header .et_search_form_container input::-moz-placeholder{color:#af1f32 !important}.et-fixed-header .et_search_form_container input::-webkit-input-placeholder{color:#af1f32 !important}.et-fixed-header .et_search_form_container input:-ms-input-placeholder{color:#af1f32 !important}.et-fixed-header #top-menu li.current-menu-ancestor > a,
.et-fixed-header #top-menu li.current-menu-item>a{color:#af1f32 !important}.et-fixed-header#top-header
a{color:#af1f32}}@media only screen and ( min-width: 1350px){.et_pb_row{padding:27px
0}.et_pb_section{padding:54px
0}.single.et_pb_pagebuilder_layout.et_full_width_page
.et_post_meta_wrapper{padding-top:81px}.et_pb_section.et_pb_section_first{padding-top:inherit}.et_pb_fullwidth_section{padding:0}}@media only screen and ( max-width: 980px ){}@media only screen and ( max-width: 767px ){}</style><style class="et_heading_font">h1,h2,h3,h4,h5,h6{font-family:'Arvo',Georgia,"Times New Roman",serif}</style><style class="et_body_font">body,input,textarea,select{font-family:'Trebuchet','Trebuchet MS',Helvetica,Arial,Lucida,sans-serif}</style><style class="et_all_buttons_font">.et_pb_button{font-family:'Arvo',Georgia,"Times New Roman",serif}</style><style class="et_primary_nav_font">#main-header,#et-top-navigation{font-family:'Montserrat',Helvetica,Arial,Lucida,sans-serif}</style><style class="et_secondary_nav_font">#top-header
.container{font-family:'Nunito',Helvetica,Arial,Lucida,sans-serif}</style><style id="module-customizer-css"></style><link
rel="shortcut icon" href="https://www.ericamauter.org/wp-content/uploads/2016/12/Just-E.png" /><meta
name="title" content="Erica Mauter" /><meta
name="description" content="Minneapolis City Council Ward 11" /><style type="text/css" id="custom-background-css">body.custom-background{background-color:#fff}</style><link
rel="stylesheet" type="text/css" id="wp-custom-css" href="https://www.ericamauter.org/?custom-css=85b6687b06" /><meta
property="og:locale" content="en_US"/><meta
property="og:site_name" content="Erica Mauter"/><meta
property="og:title" content="Erica Mauter"/><meta
property="og:url" content="https://www.ericamauter.org/events/TEC%20Debug:%20vendor%20placeholder%20was%20not%20loaded%20before%20its%20dependant%20file%20tribe-events-bar.js"/><meta
property="og:type" content="article"/><meta
property="og:description" content="Erica Mauter is running for Minneapolis City Council to represent the Ward 11 neighborhoods of Wenonah, Keewaydin, Northrop, Hale, Page, Diamond Lake, Windom, and Tangletown."/><meta
property="og:image" content="https://www.ericamauter.org/wp-content/uploads/2016/12/Mauter-Logo-Launch.png"/><meta
property="article:publisher" content="https://www.facebook.com/EricaForMpls/"/><meta
itemprop="name" content="Erica Mauter"/><meta
itemprop="description" content="Erica Mauter is running for Minneapolis City Council to represent the Ward 11 neighborhoods of Wenonah, Keewaydin, Northrop, Hale, Page, Diamond Lake, Windom, and Tangletown."/><meta
itemprop="image" content="https://www.ericamauter.org/wp-content/uploads/2016/12/Mauter-Logo-Launch.png"/><meta
name="twitter:title" content="Erica Mauter"/><meta
name="twitter:url" content="https://www.ericamauter.org/events/TEC%20Debug:%20vendor%20placeholder%20was%20not%20loaded%20before%20its%20dependant%20file%20tribe-events-bar.js"/><meta
name="twitter:description" content="Erica Mauter is running for Minneapolis City Council to represent the Ward 11 neighborhoods of Wenonah, Keewaydin, Northrop, Hale, Page, Diamond Lake, Windom, and Tangletown."/><meta
name="twitter:image" content="https://www.ericamauter.org/wp-content/uploads/2016/12/Mauter-Logo-Launch.png"/><meta
name="twitter:card" content="summary_large_image"/><meta
name="twitter:site" content="@ericamauter"/></head><body
class="error404 custom-background et_monarch tribe-no-js et_bloom et_button_no_icon et_pb_button_helper_class et_fullwidth_nav et_fixed_nav et_show_nav et_hide_fixed_logo et_cover_background et_pb_gutter et_pb_gutters3 et_primary_nav_dropdown_animation_fade et_secondary_nav_dropdown_animation_fade et_pb_footer_columns4 et_header_style_centered et_right_sidebar et_divi_theme unknown"><div
id="page-container">
<header
id="main-header" data-height-onload="150"><div
class="container clearfix et_menu_container"><div
class="logo_container">
<span
class="logo_helper"></span>
<a
href="https://www.ericamauter.org/">
<img
src="https://www.ericamauter.org/staging/1949/wp-content/uploads/2016/12/Mauter-Logo-Launch-transparent.png" alt="Erica Mauter" id="logo" data-height-percentage="100" />
</a></div><div
id="et-top-navigation" data-height="150" data-fixed-height="40">
<nav
id="top-menu-nav"><ul
id="top-menu" class="nav"><li
id="menu-item-130" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-130"><a
href="https://www.ericamauter.org/meet-erica/">Meet Erica</a></li><li
id="menu-item-131" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-131"><a
href="https://www.ericamauter.org/issues/">Issues</a></li><li
id="menu-item-133" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-133"><a
href="https://www.ericamauter.org/volunteer/">Volunteer</a></li><li
id="menu-item-134" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-134"><a
href="https://www.ericamauter.org/caucus-information/">Caucus Info</a></li><li
id="menu-item-318" class="get-started menu-item menu-item-type-post_type menu-item-object-page menu-item-318"><a
href="https://www.ericamauter.org/donate/">Donate</a></li></ul>						</nav><div
id="et_mobile_nav_menu"><div
class="mobile_nav closed">
<span
class="select_page">Select Page</span>
<span
class="mobile_menu_bar mobile_menu_bar_toggle"></span></div></div></div></div><div
class="et_search_outer"><div
class="container et_search_form_container"><form
role="search" method="get" class="et-search-form" action="https://www.ericamauter.org/">
<input
type="search" class="et-search-field" placeholder="Search &hellip;" value="" name="s" title="Search for:" /></form>
<span
class="et_close_search_field"></span></div></div>
</header><div
id="et-main-area"><div
id="main-content"><div
class="container"><div
id="content-area" class="clearfix"><div
id="left-area">
<article
id="post-0" class="et_pb_post not_found"><div
class="entry"><h1>No Results Found</h1><p>The page you requested could not be found. Try refining your search, or use the navigation above to locate the post.</p></div>
</article></div><div
id="sidebar"><div
id="monarchwidget-3" class="et_pb_widget widget_monarchwidget"><h4 class="widgettitle">Follow Erica</h4><div
class="et_social_networks et_social_1col et_social_simple et_social_rectangle et_social_top et_social_nospace et_social_mobile_on et_social_withnetworknames et_social_outer_dark widget_monarchwidget"><ul
class="et_social_icons_container"><li
class="et_social_facebook">
<a
href="https://www.facebook.com/EricaForMpls/" class="et_social_follow" data-social_name="facebook" data-social_type="follow" data-post_id="0" target="_blank">
<i
class="et_social_icon et_social_icon_facebook"></i><div
class="et_social_network_label"><div
class="et_social_networkname">Facebook</div></div>
<span
class="et_social_overlay"></span>
</a></li><li
class="et_social_twitter">
<a
href="https://twitter.com/ericamauter" class="et_social_follow" data-social_name="twitter" data-social_type="follow" data-post_id="0" target="_blank">
<i
class="et_social_icon et_social_icon_twitter"></i><div
class="et_social_network_label"><div
class="et_social_networkname">Twitter</div></div>
<span
class="et_social_overlay"></span>
</a></li><li
class="et_social_instagram">
<a
href="https://www.instagram.com/erica.mauter/" class="et_social_follow" data-social_name="instagram" data-social_type="follow" data-post_id="0" target="_blank">
<i
class="et_social_icon et_social_icon_instagram"></i><div
class="et_social_network_label"><div
class="et_social_networkname">Instagram</div></div>
<span
class="et_social_overlay"></span>
</a></li></ul></div></div><div
id="bloomwidget-2" class="et_pb_widget widget_bloomwidget"><div
class="et_bloom_widget_content et_bloom_make_form_visible et_bloom_optin et_bloom_optin_1" style="display: none;"><style type="text/css">.et_bloom .et_bloom_optin_1
.et_bloom_form_content{background-color:#80b6c6 !important}.et_bloom .et_bloom_optin_1 .et_bloom_form_container
.et_bloom_form_header{background-color:#af1f32 !important}.et_bloom .et_bloom_optin_1 .et_bloom_form_content
button{background-color:#fff !important}.et_bloom .et_bloom_optin_1 .et_bloom_form_content
button{background-color:#fff !important}.et_bloom .et_bloom_optin_1 h2, .et_bloom .et_bloom_optin_1 h2 span, .et_bloom .et_bloom_optin_1 h2
strong{font-family:"Arvo",Georgia,"Times New Roman",serif}.et_bloom .et_bloom_optin_1 p, .et_bloom .et_bloom_optin_1 p span, .et_bloom .et_bloom_optin_1 p strong, .et_bloom .et_bloom_optin_1 form input, .et_bloom .et_bloom_optin_1 form button
span{font-family:"Open Sans",Helvetica,Arial,Lucida,sans-serif}h2{font-family:'Arvo',Georgia,"Times New Roman",serif;</style><div
class="et_bloom_form_container  et_bloom_form_text_light"><div
class="et_bloom_form_container_wrapper clearfix"><div
class="et_bloom_header_outer"><div
class="et_bloom_form_header et_bloom_header_text_light"><div
class="et_bloom_form_text"><h2>Sign up for Campaign Updates</h2></div></div></div><div
class="et_bloom_form_content et_bloom_3_fields et_bloom_bottom_stacked"><form
method="post" class="clearfix"><p
class="et_bloom_popup_input et_bloom_subscribe_name">
<input
placeholder="First Name" maxlength="50"></p><p
class="et_bloom_popup_input et_bloom_subscribe_last">
<input
placeholder="Last Name" maxlength="50"></p><p
class="et_bloom_popup_input et_bloom_subscribe_email">
<input
placeholder="Email"></p><button
data-optin_id="optin_1" data-service="mailchimp" data-list_id="00b4cc2624" data-page_id="0" data-account="MauterCampaign" data-disable_dbl_optin="" class="et_bloom_submit_subscription">
<span
class="et_bloom_subscribe_loader"></span>
<span
class="et_bloom_button_text et_bloom_button_text_color_dark">SUBSCRIBE!</span>
</button></form><div
class="et_bloom_success_container">
<span
class="et_bloom_success_checkmark"></span></div><h2 class="et_bloom_success_message">You have Successfully Subscribed!</h2></div></div>
<span
class="et_bloom_close_button"></span></div></div></div></div></div></div></div><span
class="et_pb_scroll_top et-pb-icon"></span><footer
id="main-footer"><div
class="container"><div
id="footer-widgets" class="clearfix"><div
class="footer-widget"><div
id="image-2" class="fwidget et_pb_widget widget_image"><div
class="jetpack-image-container"><img
src="https://www.ericamauter.org/wp-content/uploads/2016/12/Mauter-Logo-Launch.png" alt="Mauter Launch Logo blue" class="aligncenter" width="2048" height="1335" /></div></div></div><div
class="footer-widget"><div
id="text-2" class="fwidget et_pb_widget widget_text"><div
class="textwidget"></div></div></div><div
class="footer-widget"><div
id="text-3" class="fwidget et_pb_widget widget_text"><h4 class="title">Upcoming Events</h4><div
class="textwidget"><ul
class="ecs-event-list"><li
class="ecs-event"><h4 class="entry-title summary"><a
href="https://www.ericamauter.org/event/kick-off-party-for-erica-mauter-for-ward-11/" rel="bookmark">Kick Off Party for Erica Mauter for Ward 11!</a></h4><span
class="duration time"><span
class="tribe-event-date-start">January 26 @ 6:00 pm</span> - <span
class="tribe-event-time">8:00 pm</span> <span
class='timezone'> CST </span></span></li><li
class="ecs-event"><h4 class="entry-title summary"><a
href="https://www.ericamauter.org/event/precinct-caucuses/" rel="bookmark">Precinct Caucuses</a></h4><span
class="duration time"><span
class="tribe-event-date-start">April 4</span></span></li><li
class="ecs-event"><h4 class="entry-title summary"><a
href="https://www.ericamauter.org/event/ward-11-convention/" rel="bookmark">Ward 11 Convention</a></h4><span
class="duration time"><span
class="tribe-event-date-start">April 29</span></span></li></ul></div></div></div><div
class="footer-widget last"><div
id="facebook-likebox-2" class="fwidget et_pb_widget widget_facebook_likebox"><div
id="fb-root"></div><div
class="fb-page" data-href="https://www.facebook.com/EricaForMpls/" data-width="340"  data-height="130" data-hide-cover="false" data-show-facepile="false" data-show-posts="false"><div
class="fb-xfbml-parse-ignore"><blockquote
cite="https://www.facebook.com/EricaForMpls/"><a
href="https://www.facebook.com/EricaForMpls/"></a></blockquote></div></div></div></div></div></div><div
id="footer-bottom"><div
class="container clearfix"><ul
class="et-social-icons"><li
class="et-social-icon et-social-facebook">
<a
href="https://www.facebook.com/EricaForMpls/" class="icon">
<span>Facebook</span>
</a></li><li
class="et-social-icon et-social-twitter">
<a
href="https://twitter.com/ericamauter" class="icon">
<span>Twitter</span>
</a></li></ul><p
id="footer-info">Copyright &copy; 2017 <a
href=""></a> | Prepared & paid for by Neighbors for Erica Mauter, 4631 Harriet Ave Minneapolis, MN 55419 <a
href=""></a></p></div></div>
</footer></div></div><div
class="et_social_pin_images_outer"><div
class="et_social_pinterest_window"><div
class="et_social_modal_header"><h3>Pin It on Pinterest</h3><span
class="et_social_close"></span></div><div
class="et_social_pin_images" data-permalink="https://www.ericamauter.org/event/ward-11-convention/" data-title="Ward 11 Convention" data-post_id="379"></div></div></div> <script>(function(body){'use strict';body.className=body.className.replace(/\btribe-no-js\b/,'tribe-js');})(document.body);</script> <div
style="display:none"></div><style type="text/css" id="et-builder-page-custom-style">.et_pb_section{background-color: }</style><script type='text/javascript'>var tribe_l10n_datatables={"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done"}};</script><script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');ga('create','UA-89088460-1','auto');ga('send','pageview');</script> <script defer type="text/javascript" src="https://www.ericamauter.org/wp-content/cache/minify/aac1d.js"></script> <script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201703'></script> <script defer type="text/javascript" src="https://www.ericamauter.org/wp-content/cache/minify/1d222.js"></script> <script type='text/javascript'>var monarchSettings={"ajaxurl":"https:\/\/www.ericamauter.org\/wp-admin\/admin-ajax.php","pageurl":"","stats_nonce":"2343ca039e","share_counts":"088c9ffe4b","follow_counts":"174522668a","total_counts":"6daabdf54e","media_single":"f1e082b96f","media_total":"a08eed0558","generate_all_window_nonce":"e29623484a","no_img_message":"No images available for sharing on this page"};</script> <script defer type="text/javascript" src="https://www.ericamauter.org/wp-content/cache/minify/8ee3e.js"></script> <script type='text/javascript'>var jpfbembed={"appid":"249643311490","locale":"en_US"};</script> <script defer type="text/javascript" src="https://www.ericamauter.org/wp-content/cache/minify/2b8ee.js"></script> <script type='text/javascript'>var et_pb_custom={"ajaxurl":"https:\/\/www.ericamauter.org\/wp-admin\/admin-ajax.php","images_uri":"https:\/\/www.ericamauter.org\/wp-content\/themes\/Divi\/images","builder_images_uri":"https:\/\/www.ericamauter.org\/wp-content\/themes\/Divi\/includes\/builder\/images","et_frontend_nonce":"de98069d42","subscription_failed":"Please, check the fields below to make sure you entered the correct information.","et_ab_log_nonce":"dc71ad29b8","fill_message":"Please, fill in the following fields:","contact_error_message":"Please, fix the following errors:","invalid":"Invalid email","captcha":"Captcha","prev":"Prev","previous":"Previous","next":"Next","wrong_captcha":"You entered the wrong number in captcha.","is_builder_plugin_used":"","ignore_waypoints":"no","is_divi_theme_used":"1","widget_search_selector":".widget_search","is_ab_testing_active":"","page_id":"","unique_test_id":"","ab_bounce_rate":"","is_cache_plugin_active":"yes","is_shortcode_tracking":""};</script> <script defer type="text/javascript" src="https://www.ericamauter.org/wp-content/cache/minify/c3887.js"></script> <script type='text/javascript'>var bloomSettings={"ajaxurl":"https:\/\/www.ericamauter.org\/wp-admin\/admin-ajax.php","pageurl":"","stats_nonce":"4f773cc1b5","subscribe_nonce":"f58c85e1c8","is_user_logged_in":"not_logged"};</script> <script defer type="text/javascript" src="https://www.ericamauter.org/wp-content/cache/minify/1c99f.js"></script> <script type="text/css" id="tmpl-tribe_customizer_css">.tribe-events-list.tribe-events-loop.tribe-event-featured,.tribe-events-list#tribe-events-day.tribe-events-loop.tribe-event-featured,.type-tribe_events.tribe-events-photo-event.tribe-event-featured.tribe-events-photo-event-wrap,.type-tribe_events.tribe-events-photo-event.tribe-event-featured.tribe-events-photo-event-wrap:hover{background-color:#0ea0d7;}#tribe-events-content table.tribe-events-calendar.type-tribe_events.tribe-event-featured{background-color:#0ea0d7;}.tribe-events-list-widget.tribe-event-featured,.tribe-events-venue-widget.tribe-event-featured,.tribe-mini-calendar-list-wrapper.tribe-event-featured,.tribe-events-adv-list-widget.tribe-event-featured.tribe-mini-calendar-event{background-color:#0ea0d7;}.tribe-grid-body.tribe-event-featured.tribe-events-week-hourly-single{background-color:rgba(14,160,215,.7);border-color:#0ea0d7;}.tribe-grid-body.tribe-event-featured.tribe-events-week-hourly-single:hover{background-color:#0ea0d7;}</script><style type="text/css" id="tribe_customizer_css">.tribe-events-list .tribe-events-loop .tribe-event-featured,
.tribe-events-list #tribe-events-day.tribe-events-loop .tribe-event-featured,
.type-tribe_events.tribe-events-photo-event.tribe-event-featured .tribe-events-photo-event-wrap,
.type-tribe_events.tribe-events-photo-event.tribe-event-featured .tribe-events-photo-event-wrap:hover{background-color:#0ea0d7}#tribe-events-content table.tribe-events-calendar .type-tribe_events.tribe-event-featured{background-color:#0ea0d7}.tribe-events-list-widget .tribe-event-featured,
.tribe-events-venue-widget .tribe-event-featured,
.tribe-mini-calendar-list-wrapper .tribe-event-featured,
.tribe-events-adv-list-widget .tribe-event-featured .tribe-mini-calendar-event{background-color:#0ea0d7}.tribe-grid-body .tribe-event-featured.tribe-events-week-hourly-single{background-color:rgba(14,160,215, .7 );border-color:#0ea0d7}.tribe-grid-body .tribe-event-featured.tribe-events-week-hourly-single:hover{background-color:#0ea0d7}</style><style type="text/css" media="screen">#footer-widgets{padding-top:30px}.footer-widget{margin-bottom:30px!important}#main-footer{background-color:#80b6c6!important}.footer-widget
.title{font-size:18px}.footer-widget, .footer-widget li, .footer-widget li
a{color:#ffffff!important;font-size:16px}#footer-bottom{background-color:#80b6c6}#footer-bottom{padding:10px
0 5px}#footer-info, #footer-info
a{color:#fff}#footer-info, #footer-info
a{font-size:11px}#footer-bottom ul.et-social-icons li
a{color:#fff}#footer-bottom ul.et-social-icons li a:hover{color:#af1f32!important}#footer-bottom ul.et-social-icons li
a{font-size:24px}#footer-bottom ul.et-social-icons
li{margin-left:18px}#sidebar
h4.widgettitle{font-size:18px}#sidebar li, #sidebar li
a{font-size:14px}</style> <script type='text/javascript' src='https://stats.wp.com/e-201703.js' async defer></script> <script type='text/javascript'>_stq=window._stq||[];_stq.push(['view',{v:'ext',j:'1:4.5',blog:'121136989',post:'0',tz:'-6',srv:'www.ericamauter.org'}]);_stq.push(['clickTrackerInit','121136989','0']);</script> </body></html>