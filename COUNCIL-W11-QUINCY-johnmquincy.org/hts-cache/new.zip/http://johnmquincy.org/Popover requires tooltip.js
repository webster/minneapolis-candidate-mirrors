<!DOCTYPE html>
<html class="" lang="en-US" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

	
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Page not found &#8211; John Quincy</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="John Quincy &raquo; Feed" href="http://johnmquincy.org/feed/" />
<link rel="alternate" type="application/rss+xml" title="John Quincy &raquo; Comments Feed" href="http://johnmquincy.org/comments/feed/" />
			<link rel="shortcut icon" href="//johnmquincy.org/wp-content/uploads/2016/12/header-logo.png" type="image/x-icon" />
					<!-- For iPad Retina display -->
			<link rel="apple-touch-icon-precomposed" sizes="144x144" href="">
				<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/johnmquincy.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.1"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://johnmquincy.org/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.6' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-css-css'  href='http://johnmquincy.org/wp-content/plugins/post-carousel/assets/css/owl.carousel.css' type='text/css' media='all' />
<link rel='stylesheet' id='pc-style-css'  href='http://johnmquincy.org/wp-content/plugins/post-carousel/assets/css/style.css?ver=4.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='avada-stylesheet-css'  href='http://johnmquincy.org/wp-content/themes/Avada/assets/css/style.min.css?ver=5.0.6' type='text/css' media='all' />
<!--[if lte IE 9]>
<link rel='stylesheet' id='avada-shortcodes-css'  href='http://johnmquincy.org/wp-content/themes/Avada/shortcodes.css?ver=5.0.6' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='fontawesome-css'  href='http://johnmquincy.org/wp-content/themes/Avada/assets/fonts/fontawesome/font-awesome.css?ver=5.0.6' type='text/css' media='all' />
<!--[if lte IE 9]>
<link rel='stylesheet' id='avada-IE-fontawesome-css'  href='http://johnmquincy.org/wp-content/themes/Avada/assets/fonts/fontawesome/font-awesome.css?ver=5.0.6' type='text/css' media='all' />
<![endif]-->
<!--[if lte IE 8]>
<link rel='stylesheet' id='avada-IE8-css'  href='http://johnmquincy.org/wp-content/themes/Avada/assets/css/ie8.css?ver=5.0.6' type='text/css' media='all' />
<![endif]-->
<!--[if IE]>
<link rel='stylesheet' id='avada-IE-css'  href='http://johnmquincy.org/wp-content/themes/Avada/assets/css/ie.css?ver=5.0.6' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='avada-iLightbox-css'  href='http://johnmquincy.org/wp-content/themes/Avada/ilightbox.css?ver=5.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='avada-animations-css'  href='http://johnmquincy.org/wp-content/themes/Avada/animations.css?ver=5.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='evcal_google_fonts-css'  href='//fonts.googleapis.com/css?family=Oswald%3A400%2C300%7COpen+Sans%3A400%2C400i%2C300&#038;ver=4.7.1' type='text/css' media='screen' />
<link rel='stylesheet' id='evcal_cal_default-css'  href='//johnmquincy.org/wp-content/plugins/eventON/assets/css/eventon_styles.css?ver=2.4.10' type='text/css' media='all' />
<link rel='stylesheet' id='evo_font_icons-css'  href='//johnmquincy.org/wp-content/plugins/eventON/assets/fonts/font-awesome.css?ver=2.4.10' type='text/css' media='all' />
<link rel='stylesheet' id='eventon_dynamic_styles-css'  href='//johnmquincy.org/wp-content/plugins/eventON/assets/css/eventon_dynamic_styles.css?ver=4.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='fusion-builder-shortcodes-css'  href='http://johnmquincy.org/wp-content/plugins/fusion-builder/css/fusion-shortcodes.min.css?ver=1.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='avada-dynamic-css-css'  href='//johnmquincy.org/wp-content/uploads/avada-styles/avada-global.css?timestamp=1483217349&#038;ver=5.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='avada_google_fonts-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A400%7CLibre+Franklin%3A400&#038;subset=latin' type='text/css' media='all' />
<script type='text/javascript' src='http://johnmquincy.org/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://johnmquincy.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://johnmquincy.org/wp-content/themes/Avada/assets/js/html5shiv.js?ver=5.0.6'></script>
<![endif]-->
<!--[if lt IE 9]>
<script type='text/javascript' src='http://johnmquincy.org/wp-content/themes/Avada/assets/js/excanvas.js?ver=5.0.6'></script>
<![endif]-->
<link rel='https://api.w.org/' href='http://johnmquincy.org/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://johnmquincy.org/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://johnmquincy.org/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.7.1" />


<!-- EventON Version -->
<meta name="generator" content="EventON 2.4.10" />

		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<link rel="icon" href="http://johnmquincy.org/wp-content/uploads/2016/12/header-logo-66x66.png" sizes="32x32" />
<link rel="icon" href="http://johnmquincy.org/wp-content/uploads/2016/12/header-logo.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://johnmquincy.org/wp-content/uploads/2016/12/header-logo.png" />
<meta name="msapplication-TileImage" content="http://johnmquincy.org/wp-content/uploads/2016/12/header-logo.png" />

	
	<script type="text/javascript">
		var doc = document.documentElement;
		doc.setAttribute('data-useragent', navigator.userAgent);
	</script>

	
	</head>
<body class="error404 fusion-body no-tablet-sticky-header no-mobile-sticky-header no-mobile-slidingbar mobile-logo-pos-left layout-wide-mode fusion-top-header menu-text-align-left mobile-menu-design-modern fusion-image-hovers fusion-show-pagination-text">
				<div id="wrapper" class="">
		<div id="home" style="position:relative;top:1px;"></div>
				
		
			<header class="fusion-header-wrapper">
				<div class="fusion-header-v1 fusion-logo-left fusion-sticky-menu-1 fusion-sticky-logo-1 fusion-mobile-logo- fusion-mobile-menu-design-modern ">
					<div class="fusion-header-sticky-height"></div>
<div class="fusion-header">
	<div class="fusion-row">
		
<div class="fusion-logo" data-margin-top="31px" data-margin-bottom="31px" data-margin-left="0px" data-margin-right="0px">
				<a class="fusion-logo-link" href="http://johnmquincy.org/">
						<img src="//johnmquincy.org/wp-content/uploads/2016/12/header-logo.png" width="323" height="128" alt="John Quincy" class="fusion-logo-1x fusion-standard-logo" />

							<img src="//johnmquincy.org/wp-content/uploads/2016/12/header-logo.png" width="323" height="128" alt="John Quincy" class="fusion-standard-logo fusion-logo-2x" />
			
			<!-- mobile logo -->
			
			<!-- sticky header logo -->
											<img src="//johnmquincy.org/wp-content/uploads/2016/12/header-logo.png" width="323" height="128" alt="John Quincy" class="fusion-logo-1x fusion-sticky-logo-1x" />

									<img src="//johnmquincy.org/wp-content/uploads/2016/12/header-logo.png" width="323" height="128" alt="John Quincy" class="fusion-logo-2x fusion-sticky-logo-2x" />
									</a>
		</div>		<nav class="fusion-main-menu"><ul id="menu-coming-soon" class="fusion-menu"><li  id="menu-item-855"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-855"  ><a  href="http://johnmquincy.org"><span class="menu-text">Home</span></a></li><li  id="menu-item-858"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-858"  ><a  href="#about"><span class="menu-text">About John</span></a></li><li  id="menu-item-856"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-856"  ><a  href="#issues"><span class="menu-text">Priorities</span></a></li><li  id="menu-item-859"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-859"  ><a  href="#donate"><span class="menu-text">Donate</span></a></li><li  id="menu-item-857"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-857"  ><a  href="#events"><span class="menu-text">Events</span></a></li><li  id="menu-item-860"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-860"  ><a  href="#contact"><span class="menu-text">Get Involved</span></a></li></ul></nav><nav class="fusion-main-menu fusion-sticky-menu"><ul id="menu-main-menu-1" class="fusion-menu"><li   class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-855"  ><a  href="http://johnmquincy.org"><span class="menu-text">Home</span></a></li><li   class="menu-item menu-item-type-custom menu-item-object-custom menu-item-858"  ><a  href="#about"><span class="menu-text">About John</span></a></li><li   class="menu-item menu-item-type-custom menu-item-object-custom menu-item-856"  ><a  href="#issues"><span class="menu-text">Priorities</span></a></li><li   class="menu-item menu-item-type-custom menu-item-object-custom menu-item-859"  ><a  href="#donate"><span class="menu-text">Donate</span></a></li><li   class="menu-item menu-item-type-custom menu-item-object-custom menu-item-857"  ><a  href="#events"><span class="menu-text">Events</span></a></li><li   class="menu-item menu-item-type-custom menu-item-object-custom menu-item-860"  ><a  href="#contact"><span class="menu-text">Get Involved</span></a></li></ul></nav>			<div class="fusion-mobile-menu-icons">
							<a href="#" class="fusion-icon fusion-icon-bars"></a>
		
		
			</div>


<nav class="fusion-mobile-nav-holder"></nav>

	<nav class="fusion-mobile-nav-holder fusion-mobile-sticky-nav-holder"></nav>
	</div>
</div>
				</div>
				<div class="fusion-clearfix"></div>
			</header>
					
		<div id="sliders-container">
					</div>
				
							
		
		
						<div id="main" class="clearfix " style="">
			<div class="fusion-row" style="">
<div id="content" class="full-width">
	<div id="post-404page">
		<div class="post-content">
			<div class="fusion-title fusion-title-size-two sep-single" style="margin-top:0px;margin-bottom:0px;"><h2 class="title-heading-left">Oops, This Page Could Not Be Found!</h2><div class="title-sep-container"><div class="title-sep sep-single"></div></div></div>			<div class="fusion-clearfix"></div>
			<div class="error-page">
				<div class="fusion-columns fusion-columns-3">
					<div class="fusion-column col-lg-4 col-md-4 col-sm-4">
						<div class="error-message">404</div>
					</div>
					<div class="fusion-column col-lg-4 col-md-4 col-sm-4 useful-links">
						<h3>Helpful Links</h3>
												<ul id="checklist-1" class="error-menu list-icon list-icon-arrow circle-yes"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-855"><a href="http://johnmquincy.org">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-858"><a href="#about">About John</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-856"><a href="#issues">Priorities</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-859"><a href="#donate">Donate</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-857"><a href="#events">Events</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-860"><a href="#contact">Get Involved</a></li>
</ul>					</div>
					<div class="fusion-column col-lg-4 col-md-4 col-sm-4">
						<h3>Search Our Website</h3>
						<p>Can&#039;t find what you need? Take a moment and do a search below!</p>
						<div class="search-page-search-form">
							<form role="search" class="searchform" method="get" action="http://johnmquincy.org/">
	<div class="search-table">
		<div class="search-field">
			<input type="text" value="" name="s" class="s" placeholder="Search ..." />
		</div>
		<div class="search-button">
			<input type="submit" class="searchsubmit" value="&#xf002;" />
		</div>
	</div>
</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

				</div>  <!-- fusion-row -->
			</div>  <!-- #main -->
			
			
			
			
										
				<div class="fusion-footer fusion-footer-parallax">

										
																
						<footer id="footer" class="fusion-footer-copyright-area fusion-footer-copyright-center">
							<div class="fusion-row">
								<div class="fusion-copyright-content">

											<div class="fusion-copyright-notice">
			<div>Prepared and Paid for by the Neighbors for John Quincy – 5157 Oakland Avenue South, Minneapolis, MN 55417, Dan Jacobson, Treasurer</div>
		</div>
					<div class="fusion-social-links-footer">
				<div class="fusion-social-networks boxed-icons"><div class="fusion-social-networks-wrapper"><a  class="fusion-social-network-icon fusion-tooltip fusion-facebook fusion-icon-facebook" style="color:#eaeaea;background-color:#174897;border-color:#174897;border-radius:2px;" href="https://www.facebook.com/NeighborsforJohnQuincy/" target="_blank" rel="noopener noreferrer" data-placement="top" data-title="Facebook" data-toggle="tooltip" title="Facebook"><span class="screen-reader-text">Facebook</span></a><a  class="fusion-social-network-icon fusion-tooltip fusion-twitter fusion-icon-twitter" style="color:#eaeaea;background-color:#174897;border-color:#174897;border-radius:2px;" href="#" target="_blank" rel="noopener noreferrer" data-placement="top" data-title="Twitter" data-toggle="tooltip" title="Twitter"><span class="screen-reader-text">Twitter</span></a></div></div>			</div>
		
								</div> <!-- fusion-fusion-copyright-content -->
							</div> <!-- fusion-row -->
						</footer> <!-- #footer -->
									</div> <!-- fusion-footer -->
					</div> <!-- wrapper -->

				
		<a class="fusion-one-page-text-link fusion-page-load-link"></a>

		<!-- W3TC-include-js-head -->

				<script type="text/javascript">
		/*<![CDATA[*/
		var gmapstyles = 'default';
		/* ]]> */
		</script>		
		<div class='evo_lightboxes'>					<div class='evo_lightbox eventcard eventon_events_list' id=''>
						<div class="evo_content_in">													
							<div class="evo_content_inin">
								<div class="evo_lightbox_content">
									<a class='evolbclose '>X</a>
									<div class='evo_lightbox_body eventon_list_event evo_pop_body evcal_eventcard'></div>
								</div>
							</div>							
						</div>
					</div>
					</div><script type='text/javascript' src='http://johnmquincy.org/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://johnmquincy.org/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.6'></script>
<script type='text/javascript' src='http://johnmquincy.org/wp-content/plugins/post-carousel/assets/js/owl.carousel.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var toTopscreenReaderText = {"label":"Go to Top"};
var avadaVars = {"admin_ajax":"http:\/\/johnmquincy.org\/wp-admin\/admin-ajax.php","admin_ajax_nonce":"ee41b6ee97","protocol":"","theme_url":"http:\/\/johnmquincy.org\/wp-content\/themes\/Avada","dropdown_goto":"Go to...","mobile_nav_cart":"Shopping Cart","page_smoothHeight":"false","flex_smoothHeight":"false","language_flag":"","infinite_blog_finished_msg":"<em>All posts displayed.<\/em>","infinite_finished_msg":"<em>All items displayed.<\/em>","infinite_blog_text":"<em>Loading the next set of posts...<\/em>","portfolio_loading_text":"<em>Loading Portfolio Items...<\/em>","faqs_loading_text":"<em>Loading FAQ Items...<\/em>","order_actions":"Details","avada_rev_styles":"1","avada_styles_dropdowns":"1","blog_grid_column_spacing":"40","blog_pagination_type":"load_more_button","carousel_speed":"2500","counter_box_speed":"1000","content_break_point":"800","disable_mobile_animate_css":"0","disable_mobile_image_hovers":"1","portfolio_pagination_type":"Pagination","form_bg_color":"#ffffff","header_transparency":"1","header_padding_bottom":"0px","header_padding_top":"0px","header_position":"Top","header_sticky":"1","header_sticky_tablet":"0","header_sticky_mobile":"0","header_sticky_type2_layout":"menu_only","sticky_header_shrinkage":"1","is_responsive":"1","is_ssl":"false","isotope_type":"masonry","layout_mode":"wide","lightbox_animation_speed":"Fast","lightbox_arrows":"1","lightbox_autoplay":"0","lightbox_behavior":"all","lightbox_desc":"0","lightbox_deeplinking":"1","lightbox_gallery":"1","lightbox_opacity":"0.95","lightbox_path":"horizontal","lightbox_post_images":"1","lightbox_skin":"smooth","lightbox_slideshow_speed":"5000","lightbox_social":"1","lightbox_title":"0","lightbox_video_height":"720","lightbox_video_width":"1280","logo_alignment":"Left","logo_margin_bottom":"31px","logo_margin_top":"31px","megamenu_max_width":"1100","mobile_menu_design":"modern","nav_height":"106","nav_highlight_border":"3","page_title_fading":"1","pagination_video_slide":"0","related_posts_speed":"2500","submenu_slideout":"1","side_header_break_point":"800","sidenav_behavior":"Hover","site_width":"1170px","slider_position":"below","slideshow_autoplay":"1","slideshow_speed":"3000","smooth_scrolling":"0","status_lightbox":"1","status_totop_mobile":"1","status_vimeo":"1","status_yt":"1","testimonials_speed":"4000","tfes_animation":"sides","tfes_autoplay":"1","tfes_interval":"3000","tfes_speed":"800","tfes_width":"150","title_style_type":"single","title_margin_top":"0px","title_margin_bottom":"0px","typography_responsive":"1","typography_sensitivity":"0.60","typography_factor":"1.50","woocommerce_shop_page_columns":"","woocommerce_checkout_error":"Not all fields have been filled in correctly.","side_header_width":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='http://johnmquincy.org/wp-content/themes/Avada/assets/js/main.min.js?ver=5.0.6' async ></script> 
<!--[if IE 9]>
<script type='text/javascript' src='http://johnmquincy.org/wp-content/themes/Avada/assets/js/avada-ie9.js?ver=5.0.6'></script>
<![endif]-->
<!--[if lt IE 9]>
<script type='text/javascript' src='http://johnmquincy.org/wp-content/themes/Avada/assets/js/respond.js?ver=5.0.6'></script>
<![endif]-->
<script type='text/javascript' src='http://johnmquincy.org/wp-includes/js/wp-embed.min.js?ver=4.7.1'></script>

			</body>
</html>

<!-- Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/

Page Caching using disk: enhanced

 Served from: johnmquincy.org @ 2017-01-22 17:01:32 by W3 Total Cache -->